import React, { Component } from 'react';
import CourseNavBar from '../courseNavBar/courseNavBar';
import SideNavBar from '../SideNavBar/SideNavBar'
import Axios from 'axios';
import { Redirect } from 'react-router'


class AnnouncementDetails extends Component {
    state = { 
        title : "",
        content : "",
        gobacktoAnnouncement : false
     }
    handleAnnouncement=(event)=>{
        var url = 'http://localhost:4000/createAnnouncement/'+localStorage.getItem('courseId')+`/`+this.state.title+`/`+this.state.content
        console.log(url)
        Axios.post(url).
        then(response => {
            console.log(response)
            this.setState({gobacktoAnnouncement :true})
        })
        .catch(response => {
           // console.log(response.toString())
        })
    }
    handleTitle =(event)=>{
        this.setState({title : event.target.value})
        console.log(this.state.title)
    }
    handleContent = (event) =>{
        console.log("Inside handle contnent")
        this.setState({content : event.target.value})
    }
    render() { 
        let redirectvar = null
        if(this.state.gobacktoAnnouncement === true)
        {
            redirectvar = <Redirect to="/announcements" />
        }
        return (  
            <div>
                {redirectvar}
            <div style={{"width": "100%"}}>
            <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <div style={{"width": "5%","float":"left"}}>
                    <SideNavBar/>
                </div>
                <div style={{"width": "93%","float":"right"}}>
                    <div id="header" width="100%" >
                        <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                        <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                        <hr></hr>
                    </div>
                    <div id="maincontent" style={{"width":"100%"}}>
                        <div id="sideMenu" style={{"width":"15%"}}>
                            {/*--Side Content Nav bar */}
                            <CourseNavBar/> 
                        </div>

                        <div id="detailsTab" style={{"float":"right","width":"85%"}}>
                            
                        <table width="100%"> 
                        
                        
                        <hr></hr>
                         <tr><input type="text" placeholder="Topic Title" onChange={this.handleTitle} required></input></tr>
                         <tr> <textarea id="exampleFormControlTextarea1" rows="2" cols="90" className="mt-2" onChange={this.handleContent} required></textarea></tr>
                         <button className="btn btn-primary" onClick={this.handleAnnouncement}>Submit</button>
                         </table>  
                        </div>
    
                    
                        
                    </div>
                
                    
                    
                </div>
               
                </div>
            </div>
        );
    }
}
 
export default AnnouncementDetails;