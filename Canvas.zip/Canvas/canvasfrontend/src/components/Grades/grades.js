import React, { Component } from 'react';
import SideNavBar from '../SideNavBar/SideNavBar'
import CourseNavBar from '../courseNavBar/courseNavBar';
import axios from 'axios';

class Grades extends Component {
    state = { 
        gradesDetails:[],
        totalMarks :0,
        totalGrade : 0,
       
     }
    componentDidMount(){
        axios.get('http://localhost:4000/getGrades').
        then(response => {
                console.log("in then")
                console.log(response.data)
                this.setState({gradesDetails : this.state.gradesDetails.concat(response.data)})
                console.log("After setting",this.state.gradesDetails[0])
        })
    }
    render() { 
        let listofgrades = this.state.gradesDetails.map(grade => {
            this.state.totalMarks = this.state.totalMarks + parseInt(grade.marks, 10);
            this.state.totalGrade = this.state.totalGrade + parseInt(grade.grade,10);
            if(grade.grade==="")
            {
                return (
                    <tr>
                        <td>{grade.name}</td>
                        <td>{grade.dueDate}</td>
                        <td>{grade.marks}</td>
                        <td>-</td>
                    </tr>
                )
            }
            return (
                <tr>
                    <td>{grade.name}</td>
                    <td>{grade.dueDate}</td>
                    <td>{grade.marks}</td>
                    <td>{grade.grade}</td>
                </tr>
            )
        })
        return ( 
            <div style={{"width": "100%"}}>
      <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
          <div style={{"width": "5%","float":"left"}}>
              <SideNavBar/>
          </div>
          <div style={{"width": "93%","float":"right"}}>
              <div id="header" width="100%" >
                  <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                  <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                  <hr></hr>
              </div>
              <div id="maincontent" style={{"width":"100%"}}>
                  <div id="sideMenu" style={{"width":"15%"}}>
                      {/*--Side Content Nav bar */}
                      <CourseNavBar />
                  
                  </div>
                  <div id="detailsTab" style={{"float":"right","width":"85%"}}>
                      <div style={{"width":"80%"}}>
                        <p style={{"font-size":"1.5rem"}}>Grades for Vaishnavi Ramesh</p>
                        
                
                    
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>DueDate</th>
                                    <th>Marks</th>
                                    <th>Grades</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/*Display the Tbale row based on data recieved*/}
                                {listofgrades}
                                <tr>
                                <td><b>Total</b></td>
                                <td></td>
                                <td></td>
                                <td>{this.state.totalMarks}/{this.state.totalGrade}</td>
                                
                            </tr>
                            </tbody>
                        </table>
                        <hr></hr>
                       
              
                        
                        
                        </div>
                      <div style={{"width":"20%"}}>
                     
                      </div>
                   
                  </div>
                
              </div>
          
              
              
          </div>
         
          
      </div>

         );
    }
}
 
export default Grades;