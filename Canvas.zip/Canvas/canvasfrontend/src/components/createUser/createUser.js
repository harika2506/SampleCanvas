import React, { Component } from 'react';


class createUser extends Component {
    state = {  }
    render() { 
        return (  
            <div>
           
            Clicked
            </div>
        );
    }
}
 
export default createUser;