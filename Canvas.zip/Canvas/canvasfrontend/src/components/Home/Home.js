import React, { Component } from 'react';
import SideNavBar from '../SideNavBar/SideNavBar'
import './Home.css'
import CourseCard from '../Cards/cards'
class Home extends Component {
    state = {  }
    render() { 
        return ( 
            
            <div style={{"width": "100%"}}>
            <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <div style={{"width": "5%","float":"left"}}>
                    <SideNavBar/>
                </div>
                <div style={{"width": "93%","float":"right"}}>

                    <div style={{"width": "90%","float":"left",}} class="row mt-3">
                        <p class="col-10 phome text-dark mb-0"> Dashboard</p>
                        <i class="fa fa-ellipsis-v col-2 mt-3 text-dark"></i>
                        <hr style={{"width": "98%","color": "black", "height": "1px"}} class="text-dark mt-0" />
                       
                        <CourseCard/>

                    </div>

                    
                   {/*} <div style={{"width": "10%","float" : "right","backgroundColor":"red"}}>
                      Tab3
        </div>*/}
                </div>
               
                
            </div>
         );
    }
}
 
export default Home;

