import React, { Component } from 'react';
import axios from 'axios';
import SideNavBar from '../SideNavBar/SideNavBar'
import CourseNavBar from '../courseNavBar/courseNavBar';


class Assignments extends Component {
  constructor(props) {
    console.log("Calling constructor")
    super(props);
      this.state = {
        selectedFile: null,
        assignmentDetails : [],
        submitButtonClicked :false,
        name : "",
        marks : 0,
        dueDate : ""
      }
      var {assignmentName} = props.location.state
      console.log(assignmentName)
      localStorage.setItem('assignmentName',assignmentName)
   
  }
  componentDidMount(){
    console.log("Inside mount"+localStorage.getItem('assignmentName'))
    var url = `http://localhost:4000/getEachAssignment/`+localStorage.getItem('courseId')+`/`+localStorage.getItem('assignmentName')
    console.log(url)
    axios.get(url).
    then(response => {
            console.log("in then")
            console.log(response.data[0])
            console.log(response.data[0].name)
            this.setState({name : response.data[0].name})
            this.setState({marks : response.data[0].marks})
            this.setState({dueDate : response.data[0].dueDate})
            console.log(this.state)
            //this.setState({assignmentDetails : this.state.assignmentDetails.concat(response.data)})
            //console.log("After setting",this.state.assignmentDetails[0].name)
    }).
    catch(response => {console.log(response)})
   
}
  
  onChangeHandler=event=>{
    this.setState({
      selectedFile: event.target.files[0],
      loaded: 0,
    })
  }
  onClickHandler = () => {
    const data = new FormData() 
    data.append('file', this.state.selectedFile)
    axios.post("http://localhost:4000/upload", data, { // receive two parameter endpoint url ,form data 
  })
  .then(res => { // then print response status
    console.log(res.statusText)
  })
}
uploadAssignment=()=>{
  this.setState({submitButtonClicked : true})
}
  render() { 
    let areatoupload = null
    if(this.state.submitButtonClicked === true)
    {
      areatoupload = <div className="pt-5">
      <div className="pt-5"><input type="file" name="file" onChange={this.onChangeHandler} style={{"height": "40px"}}></input></div>
      <div><button type="button" class="btn btn-md btn-primary" onClick={this.onClickHandler}>Upload</button> </div>
      
      </div>
    }
    return ( 
      <div style={{"width": "100%"}}>
      <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
          <div style={{"width": "5%","float":"left"}}>
              <SideNavBar/>
          </div>
          <div style={{"width": "93%","float":"right"}}>
              <div id="header" width="100%" >
                  <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                  <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                  <hr></hr>
              </div>
              <div id="maincontent" style={{"width":"100%"}}>
                  <div id="sideMenu" style={{"width":"15%"}}>
                      {/*--Side Content Nav bar */}
                      <CourseNavBar />
                  
                  </div>
                  <div id="detailsTab" style={{"float":"right","width":"85%"}}>
                      <div style={{"width":"80%"}}>
                        
                        <p id="courseHeading" style={{"font-size":"1.5rem"}}> {this.state.name}
                        <button className="btn btn-primary ml-5" style={{"float":"right"}} onClick={this.uploadAssignment}>Submit Assignment</button></p>
                      
                        <hr></hr>
                        <b>Due</b>
                        <p>{this.state.dueDate}</p>
                        <b>Points</b>
                        <p>{this.state.marks}</p>
                        <b>Submitting</b>
                        <p> a file upload (Turnitin enabled)</p>
                        {areatoupload}
                        
                        </div>
                      <div style={{"width":"20%"}}>
                     
                      </div>
                   
                  </div>
                
              </div>
          
              
              
          </div>
         
          
      </div>


     );
  }
}
 
export default Assignments;