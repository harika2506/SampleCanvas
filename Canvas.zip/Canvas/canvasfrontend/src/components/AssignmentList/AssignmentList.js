import React, { Component } from 'react';
import SideNavBar from '../SideNavBar/SideNavBar'
import CourseNavBar from '../courseNavBar/courseNavBar';
import axios from 'axios'
import './Assignment.css'
import {Link} from 'react-router-dom';
import { Redirect } from 'react-router'

class AssignmentList extends Component {
    state = { 
        upcomingAssignments : [],
        completedAssignments : [],
        gotocreateAssignment : false
     }
     componentDidMount(){
        
        axios.get('http://localhost:4000/getUpcomingAssignments/'+localStorage.getItem('courseId')).
        then(response => {
                console.log("in then")
                console.log(response.data)
                this.setState({upcomingAssignments : this.state.upcomingAssignments.concat(response.data)})
                console.log("After setting",this.state.upcomingAssignments[0].name)
        })
        .catch(response => {console.log("failed")})
        axios.get('http://localhost:4000/getCompletedAssignments/'+localStorage.getItem('courseId')).
        then(response => {
                console.log("in then")
                console.log(response.data)
                this.setState({completedAssignments : this.state.completedAssignments.concat(response.data)})
                console.log("After setting",this.state.upcomingAssignments[0].name)
        })
        .catch(response => {console.log("failed")})
        
       
    }
    createAssignment=(event)=>{
        this.setState({gotocreateAssignment : true})
    }
    render() { 
        let facultybar = null
        if(localStorage.getItem('type')==='faculty')
        {
            console.log("I am a faculty")
            facultybar = <div><button className="btn-sm btn-primary" onClick={this.createAssignment}>+ Assignment</button></div>
        }
        let redirectVar = null
        if(this.state.gotocreateAssignment === true)
        {
            redirectVar = <Redirect to="/createAssignment" />
        }
        let upcomingAssignments = this.state.upcomingAssignments.map((assignment)=>{
            
            return (
               
                
                <div style={{"backgroundColor":"white"}} className="border ml-4 mr-4 ">
                
                <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <tr>
                    <td rowSpan="2"><i className="fa fa-lg fa-edit text-muted mt-4"/> </td>
                
                <tr>
                <Link 
                to={{pathname : "/Assignments",state :{'assignmentName':assignment.name}}}>
                <b> {assignment.name} </b> </Link>
                </tr>
                <tr className="text-secondary" style={{"font-size":"12px"}}>
                    <td ><b>Due </b>
                    {assignment.duedate}</td>
                    <td>   |-/    </td>
                    <td>   {assignment.marks}   </td>
                </tr>
                </tr>
               </div> 
               
               
            )
        })
        let pastAssignment= this.state.completedAssignments.map((assignment)=>{
            
            return (
                
                <div style={{"backgroundColor":"white"}} className="border ml-4 mr-4 ">
                
                <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <tr>
                    <td rowSpan="2"><i className="fa fa-lg fa-edit text-muted mt-4"/> </td>
                
                <tr>
                <Link 
                to={{pathname : "/Assignments",state :{'assignmentName':assignment.name}}}>
                <b> {assignment.name} </b> </Link>
                </tr>
                <tr className="text-secondary" style={{"font-size":"12px"}}>
                    <td ><b>Due </b>
                    {assignment.duedate}</td>
                    <td>   |-/    </td>
                    <td>   {assignment.marks}   </td>
                </tr>
                </tr>
               </div> 
              
               
            )
        })
        return ( 
            <div>
            
            {redirectVar}
            <div style={{"width": "100%"}}>
            <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <div style={{"width": "5%","float":"left"}}>
                    <SideNavBar/>
                </div>
                <div style={{"width": "93%","float":"right"}}>
                    <div id="header" width="100%" >
                        <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                        <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                        <hr></hr>
                    </div>
                    <div id="maincontent" style={{"width":"100%"}}>
                        <div id="sideMenu" style={{"width":"15%"}}>
                            {/*--Side Content Nav bar */}
                            <CourseNavBar />
                        
                        </div>
                        <div id="detailsTab" style={{"float":"right","width":"85%"}}>
                        <div className="mb-2">
                        {facultybar}
                        </div>
                        
                            <div style={{"width":"80%","backgroundColor":"#f4f4f4"}} className="mb-2 border" >
                            
                                <div className="pt-3 pb-3 ml-3" ><b className="ml-2">Upcoming Assignment</b>
                                
                                </div>
                                <div>
                                
                                {upcomingAssignments} 
                                <hr></hr>
                                </div>
                                <div className="pt-3 pb-3 ml-3" >
                                <b className="ml-2">Past Assignment</b></div>
                                <div className="pb-5">
                                {pastAssignment}
                                </div>
                                
                            </div>
                            <div style={{"width":"20%"}}>
                           
                            </div>
                         
                        </div>
                      
                    </div>
                
                    
                    
                </div>
               
                
            </div>
            </div>
         );
    }
}
 
export default AssignmentList;