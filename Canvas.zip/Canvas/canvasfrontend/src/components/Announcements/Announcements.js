import React, { Component } from 'react';
import Axios from 'axios';
import SideNavBar from '../SideNavBar/SideNavBar'
import CourseNavBar from '../courseNavBar/courseNavBar';
import { Redirect } from 'react-router'

class Announcements extends Component {
    state = {
        Announcements : [],
        makeAnnouncementPage : false
      }
    componentDidMount(){
        console.log(localStorage.getItem('courseId'))
        var url = `http://localhost:4000/getAnnouncements/`+localStorage.getItem('courseId')
        console.log(url)
        Axios.get(url)
        .then(
            response => this.setState({Announcements : this.state.Announcements.concat(response.data)})
        )
        .catch(
            console.log("response fails")
        )
    }
    createAnnouncement = (event)=>{
        this.setState({makeAnnouncementPage : true})
    }
    render() { 
        let redirectvar = null
        if(this.state.makeAnnouncementPage === true)
        {
            console.log("redirect please")
            redirectvar = <Redirect to='/createAnnouncement' />
     
        }
        let announcementSection = this.state.Announcements.map((announcement)=>{
            
            return (
                
                <div style={{"backgroundColor":"white"}} >
                
                <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <tr>
                    <td rowspan="2"><i class="fa fa-user-circle-o text-muted"></i></td>
                    <td><a href="#"><b>{announcement.title}</b></a></td>
                </tr>
                <tr>
                    <td width="40%"><a href="#">{announcement.content}</a></td>
                    <td rowspan="1" align="right" width="70%">{announcement.dateCreated}</td>
                    
                </tr>
                </div> 

               
               
            )
        })
        let facultybar = null
        if(localStorage.getItem('type')==='faculty')
        {
            console.log("I am a faculty")
            facultybar = <div><button className="btn-sm btn-primary" onClick={this.createAnnouncement}>+ Announcement</button></div>
        }
    
        return (  
            <div>
            {redirectvar}
            
            <div style={{"width": "100%"}}>
           
            <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <div style={{"width": "5%","float":"left"}}>
                    <SideNavBar/>
                </div>
                <div style={{"width": "93%","float":"right"}}>
                    <div id="header" width="100%" >
                        <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                        <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                        <hr></hr>
                    </div>
                    <div id="maincontent" style={{"width":"100%"}}>
                        <div id="sideMenu" style={{"width":"15%"}}>
                            {/*--Side Content Nav bar */}
                            <CourseNavBar />
                        
                        </div>
                        <div id="detailsTab" style={{"float":"right","width":"85%"}}>
                            
                              <table width="100%"> 
                              
                              {facultybar}
                              <hr></hr>
                               {announcementSection}
                               </table>  
                        </div>
                            
                           
                         
                        
                      
                    </div>
                
                    
                    
                </div>
               
                
            </div>
            </div>
        );
    }
}
 
export default Announcements;