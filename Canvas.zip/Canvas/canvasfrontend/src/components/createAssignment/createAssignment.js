import React, { Component } from 'react';
import CourseNavBar from '../courseNavBar/courseNavBar';
import SideNavBar from '../SideNavBar/SideNavBar'
import Axios from 'axios';
import { Redirect } from 'react-router'

class CreateAssignment extends Component {
    state = { 
        assignmentName : "",
        marks : "",
        dueDate :"",
        gobacktoAssignmentPage : false
     }

    handleAssignmentName = (event)=>{
        this.setState({assignmentName : event.target.value})
    }
    handleMarks =(event) =>{
        this.setState({marks : event.target.value})

    }
    handleDate =(event) =>{
        this.setState({dueDate : event.target.value})
    }
    handleAssignment =()=>{
        var url ='http://localhost:4000/createAssignment/'+localStorage.getItem('courseId')+`/`+this.state.assignmentName+`/`+this.state.marks+`/`+this.state.dueDate
        console.log(url)
        Axios.post(url)
        .then(
            response =>{
                console.log(response)
                this.setState({gobacktoAssignmentPage : true})
            }
        )
        .catch(
            response => { console.log(response)}
        )
    }
    render() { 
        let redirectvar = null
        if(this.state.gobacktoAssignmentPage === true)
        {
            redirectvar = <Redirect to="/assignmentList"/>
        }
        return (
            <div>
            {redirectvar}
            <div style={{"width": "100%"}}>
            <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <div style={{"width": "5%","float":"left"}}>
                    <SideNavBar/>
                </div>
                <div style={{"width": "93%","float":"right"}}>
                    <div id="header" width="100%" >
                        <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                        <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                        <hr></hr>
                    </div>
                    <div id="maincontent" style={{"width":"100%"}}>
                        <div id="sideMenu" style={{"width":"15%"}}>
                            {/*--Side Content Nav bar */}
                            <CourseNavBar/> 
                        </div>

                        <div id="detailsTab" style={{"float":"right","width":"85%"}}>
                            
                        <table width="100%"> 
                        
                        
                        <hr></hr>
                         <tr><input type="text" placeholder="Enter Assignment Name" onChange={this.handleAssignmentName} required></input></tr>
                         <tr><input type="text" placeholder="Enter Marks" onChange={this.handleMarks} required></input></tr>
                         <tr><input type="text" placeholder="Enter Date in YYYY-MM-DD format" onChange={this.handleDate} required></input></tr>                        
                         <button className="btn btn-primary" onClick={this.handleAssignment}>Submit</button>
                         </table>  
                        </div>
    
                    
                        
                    </div>
                
                    
                    
                </div>
               
                </div>
            </div>
          );
    }
}
 
export default CreateAssignment;