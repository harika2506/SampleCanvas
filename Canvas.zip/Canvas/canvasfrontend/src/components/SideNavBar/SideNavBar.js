import React, { Component } from 'react';
import SJSULogo from './SJSU.png'
import './SideNavBar.css'
class SideNavBar extends Component {
    state = {  }
  
    render() { 
        return ( 
            <div>
                        <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>

                        <div class="vertical-menu" >
                            <img class="responsive" src={SJSULogo} >

                            </img>
                            <a href="http://localhost:3000/profile">
                                
                                <i class="fa fa-user-circle-o fa-2x icon-white">
                                <p className="mt-1 psidenav">Account</p>  
                                </i>
                            </a>
                            <a href="http://localhost:3000/home">
                                <i class="fa fa-tachometer fa-2x icon-white">
                                <p className="mt-1 psidenav" style={{textAlign : 'left'}}>Dashboard</p>  
                                </i>
                            </a>
                            <a href="#"><i class="fa fa-book fa-2x icon-white">
                                 <p className="mt-1 psidenav">Courses</p>
                            </i>   
                            </a>
                            <a href="#"><i class="fa fa-users fa-2x icon-white">
                                <p className="mt-1 psidenav">Groups</p>
                            </i>
                                
                            </a>
                            <a href="#"><i class="fa fa-calendar fa-2x icon-white">
                                <p className="mt-1 psidenav">Calendar</p>
                                </i>
                            </a>
                            <a href="#"><i class="fa fa-envelope-open-o  fa-2x icon-white">
                                <p className="mt-1 psidenav">Inbox</p>
                                </i>
                            </a>
                            <a href="#"><i class="fa fa-question-circle  fa-2x icon-white">
                                <p className="mt-1 psidenav">Help</p>
                                </i>
                            </a>
                            <a href="#"><i class="fa fa-bank fa-2x icon-white">
                                <p className="mt-1 psidenav">Library</p>
                                </i>
                            </a>
                        </div>
            </div>
            
         );
    }
}
 
export default SideNavBar;