import React, { Component } from 'react';
import {Link} from 'react-router-dom';

import axios from 'axios';
import './cards.css'
class CourseCard extends Component {
    state = { 
            courses : [],
            colors : ['bg-info','bg-danger','bg-primary','bg-success']
     }

     componentDidMount(){
             var url = `http://localhost:4000/viewCourses/`+localStorage.getItem('userid')
             console.log(url)  
             axios.get(url).
             then(response => {
                     console.log("in then")
                     console.log(response.data)
                     this.setState({courses : this.state.courses.concat(response.data)})
                     console.log("After setting",this.state.courses)
             })
            
     }
     styleCardBackground(id)
     {
        let classes = "card-body "
        classes += this.state.colors[id]
        return classes
     }
     goToDetails()
     {
             console.log("Clicked")
     }

    render() { 
        
            let displayCards = this.state.courses.map((course,id)=>{
               return(
                <div class="shadow ml-4 mr-4  mb-4 rounded" style={{"width": "18rem","height":"18rem"}} >
                {/*<Link  to={{pathname : "#" , data :  [this.state.Coursenames,this.state.grades,this.state.courseid] }} onClick= {this.Courseshandler}  >*/}

                <Link  to={{pathname : "/courseDetails",state :{'courseId':course.courseID}}}  > 
                        <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                        <div className={this.styleCardBackground(id)} style={{"height":"60%"}}>
                                <i class="fa fa-ellipsis-v col-2 mt-3 .text-light fa-lg" style={{"float":"right"}}></i>
                                
                        </div>
                        <div className="card-body bg-light" style={{"height":"40%"}}>
                                
                                <p className="text-secondary pb-0 mb-0" style={{"textAlign":"left"}}>{course.courseName}</p> 
                                <p className="text-secondary" style={{"textAlign":"left"}}>{course.courseTerm}</p>
                                <div class="row">
                                <div className="col-3 "><i class="fa fa-bullhorn fa-lg text-secondary" ></i></div>
                                <div className="col-3 "><i class="fa fa-file-text-o fa-lg text-secondary" aria-hidden="true"></i></div>
                                <div className="col-3 "><i class="fa fa-commenting-o fa-lg text-secondary" aria-hidden="true"></i></div>
                                <div className="col-3 "><i class="fa fa-folder-open-o fa-lg text-secondary" aria-hidden="true"></i></div>
                                </div> 
                               
                        </div>
                       
                </Link>
                </div>
               )

            })
        return ( 

           
            <div  class="card-deck">
                {displayCards}
              
            </div>
            
            
         );
    }
}
 
export default CourseCard;