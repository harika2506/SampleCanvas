import React, { Component } from 'react';
import CourseNavBar from '../courseNavBar/courseNavBar';
import SideNavBar from '../SideNavBar/SideNavBar'
import axios from 'axios';


// const base64 = require('base64topdf');
// const fs = require('fs')
class FilesCanvas extends Component{
    
    state = { 
        files : [],
        filename : "",
        base64img : ""
        
    }
    
    componentDidMount(){
        axios.get('http://localhost:4000/seeFiles').
        then(response => {
                console.log("in then")
                console.log(response.data)
                this.setState({files : this.state.files.concat(response.data)})
                console.log(this.state.files[0]);
                console.log("After setting",this.state.files)
        })
    
       
    }
    
    handleDownload(value) {
        //console.log(value);
        
        var url  = 'http://localhost:4000/download-file/'+value
        
        axios.post(url,{
        }).then(response=>{
            
            // console.log("Downloaded");
            this.setState({
                base64img : response.data
            })
            
         })
         .catch(response=>console.log(response.data))
    }
    
  
  render(){
    
    let displayFiles = this.state.files.map((file,id)=>{
        
       console.log("sae" + this.state.base64img);
       console.log(this.state.files)
       return(
        <tr >
        {/*<i class="fa fa-file-pdf-ofa-2x" className="text-success" >  </i> */}

        <a href = {"data:application/pdf;base64,"+this.state.base64img} download="a.pdf"> <td  value={file} onClick={()=>this.handleDownload(file)} className="text-primary">{file}</td> </a>
         
        </tr>
    )
       

    })
    return(
    
    <div style={{"width": "100%"}}>
    <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
        <div style={{"width": "5%","float":"left"}}>
            <SideNavBar/>
        </div>
        <div style={{"width": "93%","float":"right"}}>
            <div id="header" width="100%" >
                <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                <hr></hr>
            </div>
            <div id="maincontent" style={{"width":"100%"}}>
                <div id="sideMenu" style={{"width":"15%"}}>
                    {/*--Side Content Nav bar */}
                    <CourseNavBar/> 
                </div>

                <div id="container" style={{"float":"right","width":"85%"}}>
                        <table class="table">
                        <thead>
                            <tr>
                                <th>Files</th>
                            </tr>
                        </thead>
                        <tbody>
                            {displayFiles}
                        </tbody>
                    </table>
                    {/*<a href = {"data:application/pdf;base64,"+this.state.base64img} download="a.pdf">"download"</a>*/}
                    
                    {/*<iframe src = {"data:application/pdf;base64,"+this.state.base64img} width="100%" height="1000" frameBorder="0"
    allowFullScreen></iframe>*/}

                </div>

            
                
            </div>
        
            
            
        </div>
       
        </div>
    
        
    );
    
  }
    

}

export default FilesCanvas