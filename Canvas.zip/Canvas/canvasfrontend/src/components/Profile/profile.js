import React, { Component } from 'react';
import Axios from 'axios';
import SideNavBar from '../SideNavBar/SideNavBar'
import CourseNavBar from '../courseNavBar/courseNavBar';
class Profile extends Component {
    
    state={
        profilepic:"",
        username:"",
        email:"",
        password:"",
        Aboutme:"",
        city:"",
        country:"",
        company:"",
        school:"",
        languages:"",
        gender:"",
        hometown:"",
        phonenumber:"",
        user_id:0,
        
    }
    componentDidMount()
    {
        this.setState({user_id : localStorage.getItem('userid')})
        console.log(this.state.user_id)
    }
   
    profilepicChangeHandler = (e) => {
        console.log(e.target.files[0])
        
        const data = new FormData() 
        data.append('file', e.target.files[0])
        Axios.post("http://localhost:4000/uploadprofpic", data, { // receive two parameter endpoint url ,form data
           
        })
        .then(res => { // then print response status
            console.log(res.data)
            this.setState({
                profilepic : res.data.path
            })           
        })
    }
    usernameChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            username : e.target.value
        })
    }
    emailChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            email : e.target.value
        })
    }
    passwordChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            password : e.target.value
        })
    }
    cityChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            city : e.target.value
        })
    }
    AboutmeChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            Aboutme : e.target.value
        })
    }

    countryChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            country : e.target.value
        })
    }
    schoolChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            school : e.target.value
        })
    }
    languagesChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            languages : e.target.value
        })
    }
    genderChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            gender : e.target.value
        })
    }
  
    hometownChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            hometown : e.target.value
        })
    }
    companyChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            company : e.target.value
        })
    }
    phonenumberChangeHandler = (e) => {
        console.log(e.target.value)
        this.setState({
            phonenumber : e.target.value
        })
    }
    submitProfile = (e) => {
        
        
        var link="http://localhost:4000/Update";
        console.log(link);
        
        Axios.post(link,{
            profilepic : this.state.profilepic,
            username : this.state.username,
            email:this.state.email,
            password:this.state.password,
            Aboutme:this.state.Aboutme,
            city:this.state.city,
            country:this.state.country,
            company:this.state.company,
            school:this.state.school,
            languages:this.state.languages,
            gender:this.state.gender,
            
            hometown:this.state.hometown,
            phonenumber:this.state.phonenumber,
            user_id:this.state.user_id

        }).then(res=>{
            console.log(res.data)
            
            

        }).catch(
            res =>  console.log(res.data)
        )
}
render(){
    return(
        <div>
        <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
            <div style={{"width": "5%","float":"left"}}>
                <SideNavBar/>
            </div>
            <div style={{"width": "93%","float":"right"}}>
                <div id="header" width="100%" >
                    <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                    <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                    <hr></hr>
                </div>
                <div id="maincontent" style={{"width":"100%"}}>
                    
                    <div id="detailsTab" style={{"float":"right","width":"85%"}}>
                    <div className="mb-2">
                    <div>
                    <div className = "mt-6">
                 <form>
       
                 <div class="form-group">
                       <label classname="col-md-6">Profile Picture</label> 
                       <input onChange = {this.profilepicChangeHandler} type="file" class="form-control" name="profilepic" className="col-md-5" placeholder="profilepic"/>
                 </div>
                 <div class="form-group">
                 <label classname="mr-2 col-md-2">User ID</label> 
                                   <label onChange = {this.user_idChangeHandler} type="text" class="form-control" name="user_id" className="col-md-5" placeholder="user_id">{localStorage.getItem('userid')}</label>
                  </div>
                 <div class="form-group">
                        <label className="mr-2 col-md-2">Phone Number</label> 
                       <input onChange = {this.phonenumberChangeHandler} type="text" class="form-control" name="phonenumber"  className="col-md-5" placeholder="phonenumber"/>
                 </div>
                 <div class="form-group">
                     <label className="mr-2 col-md-2">User Name</label> 
                     <input onChange = {this.usernameChangeHandler} type="text" class="form-control" name="username" className="col-md-5" placeholder="username"/>
                    </div>
                 <div class="form-group">
                    <label className="mr-2 col-md-2">Email</label> 
                           <input onChange = {this.emailChangeHandler} type="text" class="form-control" name="email" className="col-md-5" placeholder="email"/>
                </div>
                
               <div class="form-group">
               <label className="mr-2 col-md-2">City</label>
                                   <input onChange = {this.cityChangeHandler} type="text" class="form-control" name="city" className="col-md-5" placeholder="city"/>
                </div>
                <div class="form-group">
                <label className="mr-2 col-md-2">About me</label>
                                   <input onChange = {this.AboutmeChangeHandler} type="text" class="form-control" name="Aboutme" className="col-md-5" placeholder="Aboutme"/>
                </div>
                <div class="form-group">
                <label className="mr-2 col-md-2">Country</label>
                                   <input onChange = {this.countryChangeHandler} type="text" class="form-control" name="country" className="col-md-5" placeholder="country"/>
                </div>
                <div class="form-group">
                <label className="mr-2 col-md-2">School</label>
                                   <input onChange = {this.schoolChangeHandler} type="text" class="form-control" name="school" className="col-md-5" placeholder="school"/>
                </div>
                <div class="form-group">
                <label className="mr-2 col-md-2">Languages</label>
                                   <input onChange = {this.languagesChangeHandler} type="text" class="form-control" name="languages" className="col-md-5" placeholder="languages"/>
                  </div>
                  <div class="form-group">
                  <label className="mr-2 col-md-2">Company</label>
                                   <input onChange = {this.companyChangeHandler} type="text" class="form-control" name="company"  className="col-md-5" placeholder="company"/>
                  </div>
                  <div class="form-group">
                  <label className="mr-2 col-md-2">Gender</label> 
                                   <input onChange = {this.genderChangeHandler} type="text" class="form-control" name="gender" className="col-md-5" placeholder="gender"/>
                  </div>
                 
                  <div class="form-group">
                  <label className="mr-2 col-md-2">HomeTown</label>
                                   <input onChange = {this.hometownChangeHandler} type="text" class="form-control" name="hometown" className="col-md-5" placeholder="hometown"/>
                  </div>
       
                  <div class="col-3"></div>
                           <button onClick = {this.submitProfile} class="btn btn-primary">Update</button>   
                          
                   
       
       
                 </form>
                 </div>  
               </div>
                     
                    </div>
                  
                </div>
            
                
                
            </div>
           
            
        </div>
        </div>
    )
}
}
 
export default Profile;