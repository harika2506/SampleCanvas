import React, { Component } from 'react';

import './courseNavBar.css'
class CourseNavBar extends Component {
    state = {  }
  
    render() { 
        return ( 
            <div>
                        <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>

                        <div class="vertical-menuc" >
                           <i style={{"font-size":"0.5rem"}} className="ml-3">Spring 2019</i>
                           
                            <a href="http://localhost:3000/announcements">
                               
                                <p className="psidenavc mb-0">Announcements</p>    
                                
                            </a>
                            <a href="http://localhost:3000/assignmentList">
                                
                                <p className="psidenavc mb-0" style={{textAlign : 'left'}}>Assignments</p>  
                                
                            </a>
                            <a href="http://localhost:3000/courseDetails">
                                 <p className=" psidenavc mb-0">Courses</p>
                              
                            </a>
                            <a href="http://localhost:3000/grades">
                                <p className="psidenavc mb-0">Grades</p>
                           
                                
                            </a>
                            <a href="http://localhost:3000/fileViewer">
                                <p className="psidenavc mb-0">Files</p>   
                            </a>
                            <a href="http://localhost:3000/People">
                                <p className="psidenavc mb-0">People</p> 
                            </a>
                            <a href="http://localhost:3000/enrollment">
                                <p className="psidenavc mb-0">Enrollment</p> 
                            </a>
                           
                            
                        </div>
            </div>
            
         );
    }
}
 
export default CourseNavBar;