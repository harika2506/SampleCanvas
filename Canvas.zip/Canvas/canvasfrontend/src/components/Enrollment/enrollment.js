import React, { Component } from 'react';
import SideNavBar from '../SideNavBar/SideNavBar'
import CourseNavBar from '../courseNavBar/courseNavBar';
import Axios from 'axios';

class Enrollment extends Component {
    state = { 
        Waitlisted : false,
        CannotBeAdded :false,
        AddToCourse :false,
        DroppedACourse : false,
        courseId : 0
     }
    handleEnrollment = (event)=>{
        var url = `http://localhost:4000/enrollCourse/`+this.state.courseId
        Axios.post(url).
        then(response => 
            {
                console.log(response.data)
                
                
                if(response.data == "Waitlisted")
                {
                    this.setState({Waitlisted : true})
                }
                else if(response.data === "Cannot be added to the course")
                {
                    this.setState({CannotBeAdded : true})
                }
                
                else{
                    this.setState({AddToCourse : true})
                }

            })
        .catch(response => {

        })
    }
    handleDrop = (event) => {
        console.log("drop called")
        var url = 'http://localhost:4000/deleteCourse/'+this.state.courseId
        console.log(url)
        Axios.delete(url)
        .then(
            
                response => {console.log(response.data)
                    this.setState({DroppedACourse:true})
                }
            
        )
        .catch(
            
            response => {console.log(response.data)}
        
        )
    }
    handleCourseIDInput = (event) => {
        this.setState({Waitlisted : false})
        this.setState({CannotBeAdded : false})
        this.setState({AddToCourse : false})
        this.setState({courseId : parseInt(event.target.value, 10)})
        console.log(this.state.courseId)
    }
    render() { 
        let alertMessage = null
        
        if(this.state.Waitlisted === true)
        {
            console.log("calling the text")
            alertMessage = <div><p className="text-secondary mt-3">You are waitlisted for this course.</p></div>
        }
        else if(this.state.CannotBeAdded === true)
        {
            alertMessage = <div><p className="text-danger mt-3">Sorry,You cannot be added to the course. Waitlist capacity is full too</p></div>

        }
        else if(this.state.AddToCourse === true){
            alertMessage = <div><p className="text-success mt-3">Congratulations!You are added to this course</p></div>
 
        }
        else if(this.state.DroppedACourse === true){
            console.log("In this block")
            alertMessage = <div><p className="text-success mt-3">You have dropped the course</p></div>
 
        }
        return ( 
            <div>
            <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <div style={{"width": "5%","float":"left"}}>
                    <SideNavBar/>
                </div>
                <div style={{"width": "93%","float":"right"}}>
                    <div id="header" width="100%" >
                        <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                        <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                        <hr></hr>
                    </div>
                    <div id="maincontent" style={{"width":"100%"}}>
                        <div id="sideMenu" style={{"width":"15%"}}>
                            {/*--Side Content Nav bar */}
                            <CourseNavBar />
                        
                        </div>
                        <div id="detailsTab" style={{"float":"right","width":"85%"}}>
                            <div style={{"width":"80%"}}>
                              <p style={{"font-size":"1.5rem"}}>Enrollments</p>
                              
                      
                          
                             
                              <hr></hr>
                             
                              <input type="text" placeholder="Enter course ID" onChange={this.handleCourseIDInput}></input>
                              <div>
                              <button className="btn btn-primary mr-2 mt-5" onClick={this.handleEnrollment}>Enroll</button>
                              
                              <button className="btn btn-primary mt-5" onClick={this.handleDrop}>Drop</button>
                              </div>
                              {alertMessage}
                              
                              </div>
                            <div style={{"width":"20%"}}>
                           
                            </div>
                            </div>
                            </div>
                </div>
            </div>
         );
    }
}
 
export default Enrollment;