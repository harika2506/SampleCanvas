import React, { Component } from 'react';
import Login from "./Login/login"
import SignUp from "./SignUp/SignUp"
import Home from "./Home/Home"
import {Route} from 'react-router-dom';
import SideNavBar from './SideNavBar/SideNavBar';
import Cards from './Cards/cards'
import courseDetails from './courseDetails/courseDetails';
import CourseNavBar from './courseNavBar/courseNavBar';
import Assignments from './Assignments/Assignments';
import Grades from './Grades/grades'
import AssignmentList from './AssignmentList/AssignmentList'
import Announcements from './Announcements/Announcements'
import People from './People/People'
import CreateCourse from './CreateCourse/createCourse'
import Enrollment from './Enrollment/enrollment'
import Profile from './Profile/profile'
import FileViewer from './FileViewer/FileViewer';
import AnnouncementDetails from './AnnouncementDetails/AnnouncementDetails'
import FilesCanvas from './Files/Files'
import CreateAssignment from './createAssignment/createAssignment'
class Main extends Component {
    
    render() { 
        return ( 
            <div>
            <Route path="/cards" component={Cards}/>
             <Route path="/login" component={Login}/>
             <Route path="/signUp" component={SignUp}/>
             <Route path="/sideNavBar" component={SideNavBar}/>
             <Route path="/home" component={Home}/>
             <Route path="/courseDetails" component={courseDetails} />
             <Route path="/courseNavBar" component={CourseNavBar} />
             <Route path="/assignments" component={Assignments} />
             <Route path="/grades" component={Grades} />
             <Route path="/assignmentList" component={AssignmentList} />
             <Route path="/people" component={People} />
             <Route path="/announcements" component={Announcements}/>
             <Route path="/createCourse" component={CreateCourse}/>
             <Route path="/enrollment" component={Enrollment} />
             <Route path="/profile" component={Profile} />
             <Route path="/createAssignment" component={CreateAssignment} />
             <Route path="/createAnnouncement" component={AnnouncementDetails} />
             <Route path="/fileViewer" component={FilesCanvas}/>
             
            </div>
         )
    }
}
 
export default Main;