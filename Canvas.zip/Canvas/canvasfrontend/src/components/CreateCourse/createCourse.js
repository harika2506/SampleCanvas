import React, { Component } from 'react';
import { Redirect } from 'react-router-dom'
import Axios from 'axios';
class CreateCourse extends Component {
    state = { 
       courseId : 0,
       courseName : "",
       courseDept:"",
       courseDescription:"",
       courseRoom : "",
       courseCapacity:"",
       waitlistlistCapacity : "",
       courseTerm : "",
       errorMessage : false,
       backToCourse : false
     }
  
    handleSubmit = (event)=>{

        const data ={
            courseId : this.state.courseId,
            courseName : this.state.courseName,
            courseDept:this.state.courseDept,
            courseDescription:this.state.courseDescription,
            courseRoom : this.state.courseRoom,
            courseCapacity:this.state.courseCapacity,
            waitlistlistCapacity : this.state.waitlistlistCapacity,
            courseTerm : this.state.courseTerm
            
             
           }
        Axios.post("http://localhost:4000/createCourse",data)
        .then(
            response => {
                console.log("called Successfully")
                this.setState({backToCourse : true})

                event.preventDefault();
            }
        )
        .catch(
            response =>{
                this.setState({errorMessage : true})
                event.preventDefault();
            }
        )
    }
   
    handleCourseID=(event)=>{
        this.setState({courseId:event.target.value})
    }
    handleCourseName=(event)=>{
        this.setState({courseName:event.target.value})
    }
    handleCourseDepartment=(event)=>{
        this.setState({courseDept : event.target.value})
    }
    handleCourseDescription=(event)=>{
        this.setState({courseDescription : event.target.value})
    }
    handleCourseRoom=(event)=>{
        this.setState({courseRoom:event.target.value})
    }
    handleCourseCapacity=(event)=>{
        this.setState({courseCapacity:event.target.value})
    }
    handleWaitlistCapcacity=(event)=>{
        this.setState({waitlistlistCapacity:event.target.value})
    }
    handleCourseTerm=(event)=>{
        this.setState({courseTerm:event.target.value})
    }
    render() { 
        let redirectvar = null,redirectvar1=null
        if(this.state.errorMessage === true)
            redirectvar = <div>Course not created</div>
        else if(this.state.backToCourse === true)
            redirectvar1 = <Redirect to='/courseDetails'/>
        return (  
            <div>
                {redirectvar1}
            
             
            <div className="bg-light">
            <form>
            <div class="form-group row mt-5 ">
               <div class="col-md-4"></div>
               <input type="text" class="form-control col-4" id="courseId"  placeholder="Enter Course ID" onChange={this.handleCourseID}/>
               <div class="col-md-4"></div>
            </div>
            <div class="form-group row">
              <div class="col-md-4"></div>
              <input type="text" class="form-control col-4" id="courseName" placeholder="Enter Course Name" onChange={this.handleCourseName}/>
              <div class="col-md-4"></div>
            </div>
            <div class="form-group row">
                <div class="col-md-4"></div>
              <input type="text" class="form-control col-4" id="courseDept" placeholder="Enter Course Department" onChange={this.handleCourseDepartment}/>
              <div class="col-md-4"></div>
            </div>
            <div class="form-group row">
                <div class="col-md-4"></div>
              <input type="text" class="form-control col-4" id="courseDescription" placeholder="Enter Course Description" onChange={this.handleCourseDescription}/>
              <div class="col-md-4"></div>
            </div>
            <div class="form-group row">
              <div class="col-md-4"></div>
              <input type="text" class="form-control col-4" id="courseRoom" placeholder="Enter Course Room" onChange={this.handleCourseRoom}/>
              <div class="col-md-4"></div>
            </div>
            <div class="form-group row">
                <div class="col-md-4"></div>
              <input type="text" class="form-control col-4" id="courseCapacity" placeholder="Enter Course Capacity" onChange={this.handleCourseCapacity}/>
              <div class="col-md-4"></div>
            </div>
            <div class="form-group row">
                <div class="col-md-4"></div>
              <input type="text" class="form-control col-4" id="waitlistCapacity" placeholder="Enter waitlist Capacity" onChange={this.handleWaitlistCapcacity}/>
              <div class="col-md-4"></div>
            </div>
            <div class="form-group row">
                <div class="col-md-4"></div>
              <input type="text" class="form-control col-4" id="courseTerm" placeholder="Enter Course Term" onChange={this.handleCourseTerm}/>
              <div class="col-md-4"></div>
            </div>
            <div class="row">
            <div class="col-md-4"></div>
            <button type="submit" class="btn btn-primary col-4" onClick={this.handleSubmit}>Submit</button>
            <div class="col-md-4 text-danger"></div>
            </div>
            <div class="row">
            <div class="col-md-4"></div>
            <p class="col-4 text-danger" >{redirectvar}</p>
            <div class="col-md-4 "></div>
            </div>
          </form>
            </div>
            </div>
        );
    }
}
 
export default CreateCourse;