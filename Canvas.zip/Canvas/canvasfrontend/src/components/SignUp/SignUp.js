import React, { Component } from 'react';
import { Redirect } from 'react-router'
import axios from 'axios';
class SignUp extends Component {
    state = { 
        name : "",
        emailAddress : "",
        userId : "",
        password: "",
        type : "Faculty",
        backToLogin : false,
        createCoursePage : false
     }
     handleName = (e)=>{
         this.setState({name:e.target.value})
         console.log(this.state)
     }
     handleEmailAddress = (e) =>{
         this.setState({emailAddress : e.target.value})
         console.log(this.state)
     }
     handleUserId = (e) => {
         this.setState({userId : e.target.value})
         console.log(this.state)
     }
     handlePassword = (e) =>{
         this.setState({password : e.target.value})
         console.log(this.state)
     }
     setStudentType = (e)=>{
        console.log("Student selected")
        this.setState({type : e.target.value})
        console.log(this.state)
    }

    setTeacherType = (e)=>{
       this.setState({type:e.target.value})
       console.log("Teacher selected")
       console.log(this.state)
    }
    

    register = (e)=>{
        console.log("Pressed Login")
         e.preventDefault()
         var url = 'http://localhost:4000/create/'+this.state.type.toLowerCase()
         console.log(url)
         axios.post(url,{
             name :  this.state.name,
             id : this.state.userId,
             password : this.state.password,
             emailAddress : this.state.emailAddress

         }).then(response=>
            {
                console.log(response.data)
                this.setState({backToLogin : true})
            }   
         )
         .catch(response=>console.log(response.data))
    }

    render() { 
        let redirectvar = null
        if(this.state.backToLogin === true)
        {
            console.log("Inside redirect var")
            redirectvar = <Redirect to="/login" />
        }

        return (
            <div>
                {redirectvar}
            <div className="mt-5">
                    <form>
                    <div className="form-group">
                        <div class="row">
                                <div class="col-4"></div>
                                <input type="text" class="form-control col-4" id="Name" onChange={this.handleName}  placeholder="Enter Name" />
                                <div class="col-4"></div>
                        </div>
                    </div>
                    <div className="form-group">
                        <div class="row">
                                <div class="col-4"></div>
                                <input type="email" class="form-control col-4" id="email" onChange={this.handleEmailAddress} placeholder="Enter email address" />
                                <div class="col-4"></div>
                        </div>
                    </div>
                    <div className="form-group">
                        <div class="row">
                            <div class="col-4"></div>
                            <input type="text" className="form-control col-4" id="userid" onChange={this.handleUserId} placeholder="Enter your id"/>
                            <div class="col-4"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-4"></div>
                            <input type="password" className="form-control col-4" id="InputPassword1" onChange={this.handlePassword} placeholder="Enter your password"/>
                            <div class="col-4"></div>
                        </div>
                    </div>
                    <div class="row d-flex justify-content-around" >
                        <div class="col-3"></div>
                        <div class="form-check-inline">
                            <label class="form-check-label" >
                            <input type="radio" class="form-check-input" id="radio1" name="Student" value="Student" onChange={this.setStudentType} checked={this.state.type==="Student"}/>Student
                            </label>
                        </div>  
                        <div class="form-check-inline">
                            <label class="form-check-label">
                            <input type="radio" class="form-check-input" id="radio2" name="Faculty" value="Faculty" onChange={this.setTeacherType} checked={this.state.type==="Faculty"}/>Teacher
                            </label>
                        </div> 
                        <div class="col-3"></div>
                    </div>
                    <div class="row" >
                        
                            <div class="col-4"></div>
                            <button type="submit" class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0 col-4" onClick={this.register}>Register</button>
                            <div class="col-4"></div>
                        
                    </div>
                    </form>
     
            </div>
            </div>
          );
    }
}
 
export default SignUp;