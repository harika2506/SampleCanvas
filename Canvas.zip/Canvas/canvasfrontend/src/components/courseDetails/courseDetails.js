import React, { Component } from 'react';
import SideNavBar from '../SideNavBar/SideNavBar'
import { Redirect } from 'react-router'
import './courseDetails.css'
import CourseNavBar from '../courseNavBar/courseNavBar';
import Axios from 'axios';

class courseDetails extends Component {
    constructor(props) {
        super(props);
          this.state = {    
        createCourse : false,
        permissionCodeWindow :false,
        displayGeneratedPermissionCode :false,
        permissionCode : "",
        SearchTerm : "ID",
        operator : "",
        value : "",
        results : []
          }
          var {courseId} = props.location.state

          console.log(courseId) 
        
        localStorage.setItem('type','student')
        localStorage.setItem('courseId',courseId)
       let d = localStorage.getItem('type')
       
       this.setState({decisionvar:d})
    

       console.log("Printing the state")
       console.log(this.state)
       
      }
    /*state = {
        createCourse : false,
        permissionCodeWindow :false,
        displayGeneratedPermissionCode :false,
        permissionCode : ""
      }*/
    handleCreateCourse =(event)=>{
        this.setState({createCourse:true})
    }
    createPermissionCode = (event)=>{
        this.setState({permissionCodeWindow:true})
    }
    generatePassword=(event)=>{
        Axios.get("http://localhost:4000/getPasscode")
        .then(
          
            response=>{ console.log(response)
                this.setState({permissionCode : response.data})
                
            }
        )
        .catch(
            response => {console.log(response)
                console.log("Failure")
            }

        )
    }
    handleSearchTerm=(event)=>{
        this.setState({SearchTerm:event.target.value})
        
    }
    handleOperator = (event)=>{
        this.setState({operator:event.target.value})
    }
    handleValue = (event)=>{
        this.setState({value : event.target.value})
    }
    handleSearch = (event)=>{
        this.setState({results:[]})
        if(this.state.SearchTerm === "ID")
        {
        let url = `http://localhost:4000/search/courseID/`+ this.state.value +`&`+this.state.operator  
        console.log(url)
        Axios.get(url)
        .then(
            response =>{
                console.log(response)
                this.setState({results : this.state.results.concat(response.data)})
            }
        )
        .catch(
            response => {
                console.log(response)
            }
        )
        }
        else if(this.state.SearchTerm === "Course Term")
        {
            console.log(this.state)
           let url = `http://localhost:4000/search/`+ this.state.value
            Axios.get(url)
            .then(
                response => {
                    console.log(response.data)
                    this.setState({results : this.state.results.concat(response.data)})
                }

            )
            .catch(
                response => {console.log(response)}
            )
        }
        else{
            let url = `http://localhost:4000/search/courseName/`+ this.state.value +`&`+this.state.operator  
            console.log(url)
            Axios.get(url).
            then(
                response => {console.log(response)
                this.setState({results : this.state.results.concat(response.data)})}
            )
            .catch(
                response => {console.log(response)}
            )
        }
    }
    render() { 
        localStorage.setItem('type','student')
       let d = localStorage.getItem('type')
       console.log("d is",d)
       console.log(this.state.value)
        console.log(this.state.operator)
        let dynamicrenderingPart = null
       
        if(d === 'faculty')
        {
            let redirectvar=null
            let generatePermissionCode = null
            console.log("Is a faculty")
            
            if(this.state.createCourse===true)
            {
                redirectvar=<Redirect to='/createCourse'/>
            }
            else if(this.state.permissionCodeWindow===true)
            {
                generatePermissionCode = 
                <div >
                <input type="text" id="courseId"  class="mt-5 ml-5 mr-5" placeholder="Enter Course ID" />
                <input type="text" id="studentID"  class="mt-5 ml-5 mr-5" placeholder="Enter Student ID"/>
                <input type="submit" id="submit"  class=" mt-5 ml-5 mr-5" onClick={this.generatePassword}/>
                <span >Generated Permission Code is : {this.state.permissionCode}</span>
                </div>
            
            }
            dynamicrenderingPart =  <div id="detailsTab" style={{"float":"right","width":"85%"}} classname ="row">             
            <button className="btn btn-primary col-4 ml-5"  onClick={this.createPermissionCode}>Generate Permission Code</button> 
            <button className="btn btn-primary col-4 ml-5"  onClick={this.handleCreateCourse}>Create Course</button>
               
            {redirectvar}
            {generatePermissionCode}
 
            </div>
        }
        else{
            let res = null
            console.log("rendering part")
            console.log(this.state.results)
            if(this.state.results.length>=1)
            {
                
                res = this.state.results.map( element => {
                    return(
                        <tr>
                            <td className="mr-5">{element.courseID}</td>
                            <td className="mr-5">{element.courseName}</td>
                            <td className="mr-5">{element.courseRoom}</td>
                        </tr>
                    )

                })
                
            }
            dynamicrenderingPart = 
            <div id="detailsTab" style={{"float":"right","width":"85%"}} classname ="row">   
                
              
                <div class="form-group">
                <label for="sel1">Search Term</label>
                <select class="form-control col-md-6" id="sel1" onChange={this.handleSearchTerm}>
                  <option >ID</option>
                  <option >Course Term </option>
                  <option >Course Name</option>
                  
                </select>
                <label for="sel2">Search Operator</label>
                <select class="form-control col-md-6" id="sel2" onChange={this.handleOperator}>
                  <option >greater than</option>
                  <option >less than </option>
                  <option >equal to</option>
                  
                </select>
                <label for="sel3" className="mt-1">Value</label>
                <div><input type="text" className="form-control input rounded-0 col-md-6" onChange={this.handleValue}></input></div>
                
                <div style={{"text-align": "center","width":"50%"}} className="mt-5">
                   <button className="btn btn-primary" onClick={this.handleSearch}>SEARCH</button>
                   
                </div>
                {res}
            </div>
            </div>
        }
        
        return ( 
            
            
            <div style={{"width": "100%"}}>
            <script> <meta name="viewport" content="width=device-width, initial-scale=1"/>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link></script>
                <div style={{"width": "5%","float":"left"}}>
                    <SideNavBar/>
                </div>
                <div style={{"width": "93%","float":"right"}}>
                    <div id="header" width="100%" >
                        <i style={{"width":"5%"}} class="fa fa-bars fa-2x mt-4" style={{"color":"#008ee2"}}></i>
                        <p style={{"width":"95%","float":"right","font-size":"1.5rem"}} className="mt-4 text-dark">Course Name</p>
                        <hr></hr>
                    </div>
                    <div id="maincontent" style={{"width":"100%"}}>
                        <div id="sideMenu" style={{"width":"15%"}}>
                            {/*--Side Content Nav bar */}
                            <CourseNavBar/>
                        
                        </div>
                        {dynamicrenderingPart}
                    </div>
                
                    
                    
                </div>
               
                
            </div>
        
            
               
                
            
         );
    }
}
 
export default courseDetails;