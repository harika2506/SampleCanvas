import React, { Component } from 'react';
import { Redirect } from 'react-router'
import axios from 'axios'
import 'bootstrap/dist/css/bootstrap.css'



class login extends Component {
    state = { 
        userId : "",
        password : "",
        type : "Faculty",
        signUp : false,
        goToHomePage:false
     }
     handleUserId = (e)=>{
         this.setState({userId : e.target.value})
         console.log(this.state)
     }
     handlePassword = (e)=>{
        this.setState({password : e.target.value})
        console.log(this.state)
     }
   
     setStudentType = (e)=>{
         console.log("Student selected")
         this.setState({type : e.target.value})
     }

     setTeacherType = (e)=>{
        this.setState({type:e.target.value})
        console.log("Teacher selected")
     }

     handleLogin = (e) => {
         console.log("Pressed Login")
          e.preventDefault()
         var url = 'http://localhost:4000/login/'+this.state.type.toLowerCase()
         console.log(url)
         axios.post(url,{
             id : this.state.userId,
             password : this.state.password
         }).then(response=>{
             console.log(response)
             console.log("Lets fo to the next page!!!")
             localStorage.setItem('type', response.data.type);
             localStorage.setItem('userid', response.data.id);
             this.setState({goToHomePage : true})

         })
         .catch(response=>console.log(response.status))
     }

     handleSignUp = (e) =>{
         console.log("Clicked Sign Up")
         this.setState({signUp : true})
     }
   
    render() { 
        let redirectvar = null
        if(this.state.signUp === true)
            redirectvar = <Redirect to='/signUp' />
        else if(this.state.goToHomePage === true)
            redirectvar = <Redirect to='/home' />
        return ( 
            <div>
                {redirectvar}
            <div className="containe h-100">
                <h5 style={{"backgroundColor":"white" }} className="card-header text-muted text-center py-4 ">
                Connecting to <span style={{color:"blue"}}><strong> SJSU</strong></span>
                <p style={{"text-align":"center","font-size":"15px"}}>Sign-in with your San Jose State University account to access SJSU Single Sign-on</p>
                </h5>
                
                <form class="bg-light">
                     {/*User Id */}
                    <div class="row mt-5" >
                    <div class="col-4"></div>
                    <div class="form-group col-4">
                        <input onChange={this.handleUserId} type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="SJSU ID Number"/>
                    </div>
                    <div class="col-4"></div>
                    </div>
                    {/*Password*/}
                    <div class="row" >
                        <div class="col-4"></div>
                        <div class="form-group col-4"> 
                                <input type="password" onChange={this.handlePassword} class="form-control" id="exampleInputPassword1" placeholder="Password"/>
                        </div>
                        <div class="col-4"></div>
                    </div>
                    {/*student or teacher */}
                    <div class="row d-flex justify-content-around" >
                        <div class="col-3"></div>
                        <div class="form-check-inline">
                            <label class="form-check-label" >
                            <input type="radio" class="form-check-input" id="radio1" name="Student" value="Student" onChange={this.setStudentType} checked={this.state.type==="Student"}/>Student
                            </label>
                        </div>  
                        <div class="form-check-inline">
                            <label class="form-check-label">
                            <input type="radio" class="form-check-input" id="radio2" name="Faculty" value="Faculty" onChange={this.setTeacherType} checked={this.state.type==="Faculty"}/>Teacher
                            </label>
                        </div> 
                        <div class="col-3"></div>
                    </div>   
                    {/*Login Sign Up*/}
                    <div>
                   
                    <div className="row">   
                        <div className="col-5"></div>               
                             <button class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0 col-2" type="submit" onClick={this.handleLogin}>Log In</button>
                        <div className="col-5"></div>
                    </div>
                    <p className="text-center"> NOT A MEMBER? </p>
                    <div className="row">   
                        <div className="col-5"></div>               
                        <button class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0 col-2" type="submit" onClick={this.handleSignUp}>Sign Up</button>
                        <div className="col-5">
                    </div>
                </div>
                    
                    
                    
                    </div>
                </form>

                </div>   
            </div>
         );
    }
}
 
export default login;